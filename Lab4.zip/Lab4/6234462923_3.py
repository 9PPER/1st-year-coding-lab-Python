id = input('Enter student ID :').strip()
sem = int(input('Enter semester :'))
id = str(id)
year =  int(id)//(10**8)
mid = int(id)//(10**7)%10
fac = int(id)%100
if len(id) != 10:
    print('Invalid ID')
    id = int(id)
elif year<48 and year>62:
    print('Invalid ID')
elif mid!=3 and mid!=4 and mid!=7:
    print('Invalid ID')
elif fac<21 and fac>40 and fac!=51 and fac!=53:
    print('Invalid ID')
else:
    print('Valid ID')
