day,month,year = input('Today date:').split()
year = int(year)+4
print('Expiration date:',day,month,year)


