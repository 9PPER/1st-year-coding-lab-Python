a,b,c = input('enter coefficients a, b, c:').split(',')
a=float(a)
b=float(b)
c=float(c)
import math
x1 = (-b+math.sqrt((b**2)-4*a*c))/(2*a)
x2 = (-b-math.sqrt((b**2)-4*a*c))/(2*a)
print('x =',str(x1)+',',x2)


