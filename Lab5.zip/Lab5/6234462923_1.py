name = input('Enter username : ').strip()
while name != 'Sakkarin':
    name = input('Incorrect. Enter again : ').strip()
print('Hello'',',name)
