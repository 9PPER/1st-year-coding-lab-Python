number = int(input('Number of students : '))
student = 1
while student <= number:
    score = float(input('Student '+str(student)+ ' : '))
    student = student+1
    
