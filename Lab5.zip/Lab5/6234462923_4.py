number = int(input('Number of students : '))
student = 1
total = 0
passed = 0
failed = 0
n_pass = 0
n_fail = 0
while student <= number:
    score = float(input('Student '+str(student)+ ' : '))
    total = score+total
    student = student+1
    if score >= 5 :
        n_pass = n_pass+1
        passed = score+passed
    else:
        n_fail = n_fail+1
        failed = score+failed       
total = total/number   
pass_total = passed/n_pass
fail_total = failed/n_fail
print('Average score : ',total)
print('Average passing score : ',pass_total)
print('Average failing score : ',fail_total)




