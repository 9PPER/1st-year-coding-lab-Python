name = input('Enter username : ').strip()
time = 0
while name != 'Sakkarin' and time <2:
    name = input('Incorrect. Enter again : ').strip()
    time = time+1
if name != 'Sakkarin':
    print('Not allow. Incorrect name')
else :
    print('Hello'',',name)
    


