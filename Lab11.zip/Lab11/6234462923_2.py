print('Enter monyhly income in 2561 : ')
income_list = []
for i in range(1,13):
    income = input()
    income_list = income_list + [income]
quater1 = [int(i) for i in income_list[0:3]]
quater2 = [int(i) for i in income_list[3:6]]
quater3 = [int(i) for i in income_list[6:9]]
quater4 = [int(i) for i in income_list[9:12]]
total = [sum(quater1), sum(quater2), sum(quater3), sum(quater4)]
order = {}
i = 0
for m in total:
    i += 1
    order.update({m:i})
print('Hightest income in the quater',order[max(total)])