allgoods = {}
for goods in range(10):
    product,size,number = input('Enter product ID, size, number of items : ').split()
    number = int(number)
    if product in allgoods and size in allgoods[product]:
        number = number + allgoods[product][size]
    allgoods.update({(product,size):{size:number}})
print('Stocks:')
for i in allgoods:
    for m in allgoods[i]:
        print(i,m,allgoods[i][m])