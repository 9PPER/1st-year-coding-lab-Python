with open('/Users/InADream/Downloads/Lab11/score.txt') as f:
    score_list=[line.strip().split() for line in f.readlines()]
name = {}
for i in range(len(score_list)):
    score = int(score_list[i][1])
    name_list = score_list[i][0]
    name.update({score:name_list})
order = []
for i in range(len(score_list)):
    order += [int(score_list[i][1])]
order.sort(reverse=True)
for m in order:
    print(name[m])



