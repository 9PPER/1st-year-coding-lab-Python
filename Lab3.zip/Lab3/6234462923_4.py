w,wu = input('Weight : ').split()
h,hu = input('Height : ').split()
w = float(w)
wu = str(wu)
h = float(h)
hu = str(hu)
if wu == 'lbs':
    w=w*0.45
if hu == 'ft' :
    h=h*0.30
if hu == 'cm' :
    h=h/100
bmi = w/(h**2)
if bmi<18.5:
    print('ผอม')
elif bmi<23:
    print('รูปร่างปกติ')
elif bmi<25:
    print('รูปร่างอ้วน')
elif bmi<30:
    print('อ้วนระดับ 1')
else:
    print('อ้วนระดับ 2')
    




