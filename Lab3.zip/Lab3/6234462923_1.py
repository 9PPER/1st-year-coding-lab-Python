a,b,c = input('enter coefficients a, b, c:').split(',')
a=float(a)
b=float(b)
c=float(c)
d = (b**2)-(4*a*c)
import math
if d>0 and a!=0 :
    d = math.sqrt(b**2-4*a*c)
    x1 = (-b+d)/(2*a)
    x2 = (-b-d)/(2*a)
    print('x =',str(x1)+',',x2)
else:
    print('No real solution.')
