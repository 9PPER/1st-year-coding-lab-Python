import math
choice = input('Choose circle, square or rectagle :')
if choice == 'circle':
    r = float(input('Lenght of the radius of the circle : '))
    area = math.pi*(r**2)
    print('Area is',area)
elif choice == 'square':
    r = float(input('Lenght of the side of the square : '))
    area = r*r
    print('Area is',area)
elif choice == 'rectangle':
    r1,r2 = input('Lenght of the two sides of the rectangle : ').split(',')
    r1 = float(r1)
    r2 = float(r2)
    area = r1*r2
    print('Area is',area)
else:
    print('Invalid choice.')
    
    
    
    
    

    

    
