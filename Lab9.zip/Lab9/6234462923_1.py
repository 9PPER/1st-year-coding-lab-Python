with open('/Users/InADream/Downloads/Lab9/vectors.txt') as f:
    v1 = f.readline().strip().split()
    v2 = f.readline().strip().split()
if len(v1) == len(v2):
    total = [0]*len(v1)
    multi = [0]*len(v1)
    v1 = [float(i) for i in v1]
    v2 = [float(i) for i in v2]
    print('v1 =',v1)
    print('v2 =',v2)
    for i in range(len(v1)):
        total[i] = v1[i] + v2[i]
    print('v1+v2 =',total)
    for m in range(len(v1)):
        multi[m]= v1[m]*v2[m]
        total = sum(multi)
    print('v1*v2 =',total)
else:
    print('Incompatible size')
