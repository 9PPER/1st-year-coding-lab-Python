with open('/Users/InADream/Downloads/Lab9/sol.txt') as f:
    solution = f.readline().split()
with open('exam.txt') as f:
    ans =[line.split() for line in f.readlines()]
score = []
score_n = []
for i in range(len(ans)):
    ans_i = ans[i]
    score_i = 0
    for i in range(len(solution)):
        if ans_i[i] == solution[i]:
            score_i += 1
        score_n.append(score_i)
    score.append(score_i)
print('Student score:',score)
            


    