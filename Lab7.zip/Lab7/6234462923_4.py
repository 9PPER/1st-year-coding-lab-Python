text = input('Enter some text : ')
cnt = 0
i = 0
n = 0
while i < len(text):
    if text[i] == '(':
        while i+n < len(text) :
            n += 1
            if text[n] == ')':
                cnt += 1 
        i = i+n
    else:
        i += 1
print('There are '+str(cnt)+' pairs of ().')