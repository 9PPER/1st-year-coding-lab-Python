text = input('Enter text : ')
new = ''
for i in text:
    if i not in '''/.-?!"'(){},;\t''':  
       new = new+i 
print('--'+new+'--')

