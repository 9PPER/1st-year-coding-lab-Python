text = input('Enter some text : ')
cnt = 0
i = 0
while i < len(text):
    if text[i:i+2] == '62' and text[i+8:i+10] == '23' :
        cnt +=1 
        i = i+10
    else:
        i += 1
print('There are '+str(cnt)+' student IDs.')
        
        