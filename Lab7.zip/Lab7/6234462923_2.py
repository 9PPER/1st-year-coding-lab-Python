message = input('Enter your nessage : ')
text = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ abcdefghijklmnopqrstuvwxyz1234567890,.?!'
code = ',.?!MNOPQRSTUVWXYZABCDEFGHIJKLlmnopqrstuvwxyzabcdefghijk 1234567890'
newcode = ''
for i in message:
    newcode = newcode + code[text.find(i)]
print('cipher text :',newcode)