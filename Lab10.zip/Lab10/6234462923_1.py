s_id = input('Enter student ID : ').strip()
fees = {}
fee_type = ''
group1 = [21,23,25,28,30,31,32,33,35,36,37,38,39,53]
group2 = [22,24,26,27,29,34,40,51]
year1 = [48,49]
year2 = [50,51,52,53,54,55]
year3 = [56,57,58,59,60,61,62]
year =  int(s_id[0:2])
fac = int(s_id[8:10])
mid = int(s_id[2])
if len(s_id) != 10:
    print('Invalid ID')
elif year<48 and year>62:
    print('Invalid ID')
elif mid not in [3,4,7]:
    print('Invalid ID')
elif fac<21 and fac>40 and fac!=51 and fac!=53:
    print('Invalid ID')
else :
    sem = int(input('Enter semester : '))
    if sem not in [1,2,3]:
        print('Invalid semester')
    else :
        if mid != 7:
            if fac in group1 and sem == 1 or sem == 2:
                fee_type = 'a'
            elif fac in group1 and sem == 3:
                fee_type = 'b'
            elif fac in group2 and sem ==1 or sem ==2:
                fee_type = 'c'
            elif fac in group2 and sem == 3:
                fee_type = 'd'
        else :
            if fac in group1 and sem == 1 or sem == 2:
                fee_type = 'e'
            elif fac in group1 and sem == 3:
                fee_type = 'f'
            elif fac in group2 and sem ==1 or sem ==2:
                fee_type = 'g'
            elif fac in group2 and sem == 3:
                fee_type = 'h'
    print(fee_type)
    

