integer = int(input('Enter an integer : '))
if integer == 1:
    ans = 'is not a prime.'
else:
    for i in range (2,integer):
        if integer%i == 0:
            ans = 'is a prime.'
        else :
            ans = 'is not a prime.'
print(integer, ans)
