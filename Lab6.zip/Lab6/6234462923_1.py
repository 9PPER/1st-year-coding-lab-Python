word = input('Next word : ').strip()
sentence = ''
while word != '.':
    sentence = sentence+' '+str(word)
    word = input('Next word : ').strip()
print('Sentence:',sentence)
