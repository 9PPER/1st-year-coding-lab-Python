integer = int(input('Enter an integer : '))
print(integer, 'is divisible by:')
for i in range(1,integer+1):
    if integer%i == 0:
        print(i)

