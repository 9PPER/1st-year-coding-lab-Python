with open('/Users/InADream/Downloads/Lab8/move.txt') as f :
    move = [line.strip() for line in f.readlines()]
f.close()
x,y = [int(i) for i in input('Initial position : ').split(',')]
for line in move :
    if line in 'L':
        x -= 1
        if x == -10 :
            x += 1
    elif line in 'R' :
        x += 1
        if x == 10 :
            x -= 1
    elif line in 'U' :
        y += 1
        if y == 10 :
            y -= 1
    elif line in 'D' :
        y -= 1
        if y == -10 :
            y += 1
    else :
        print('Invalid Command')
        break
else:
    print('Robot stops at '+str(x)+' , '+str(y))