import itertools

with open('/Users/InADream/Downloads/Lab8/score.txt') as f :
    scoreL = []
    flat_list = []
    for line in f:
        int_list = [int(i) for i in line.split()]
        scoreL.append(int_list)

    score = list(itertools.chain(*scoreL))
    print('total :',sum(score))
