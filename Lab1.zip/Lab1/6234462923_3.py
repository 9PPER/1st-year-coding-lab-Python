N=(input('Name:'))
A=int(input('Age:'))
y=str(2562-A)
print(N + "'s year of birth is",str(y)+'.')
