N=str(input('Name:'))
A=int(input('Age:'))
y=(int(2562-A))
ly=y%100
print(N+str(ly)+"@chula.ac.th")
