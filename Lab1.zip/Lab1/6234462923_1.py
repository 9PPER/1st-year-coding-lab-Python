p=float(input('price:'))
s=int(input('shipping fee:'))
print('total:',p+s,'Bath''(',s,'Bath is shipping fee)')