F=str(input('Firstname:'))
L=str(input('Lastname:'))
a=(F+' '+L)
b=(L+', '+F)
print('Hello!',a)
print(b)


